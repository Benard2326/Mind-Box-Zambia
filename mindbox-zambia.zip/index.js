const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const chatRoute = require('./routes/chat');

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/api/chat', chatRoute);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`MindBox Zambia running on port ${PORT}`);
});