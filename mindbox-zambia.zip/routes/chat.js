const express = require('express');
const router = express.Router();
const mindboxService = require('../services/mindboxService');

router.post('/', (req, res) => {
  const { message } = req.body;
  const response = mindboxService.getResponse(message);
  res.json({ reply: response });
});

module.exports = router;