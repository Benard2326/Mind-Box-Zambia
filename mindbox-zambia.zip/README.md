# MindBox Zambia

MindBox Zambia is an AI-powered assistant that helps users with:

- 🏕 Tourism in Zambia
- 🏦 Mobile banking advice and info
- 🚖 Yango ride info
- 🚌 Intercity bus info

### How to Run

```bash
npm install
node index.js
```

API will be live at `http://localhost:3000/api/chat`

Send POST request with JSON:
```json
{ "message": "Tell me about tourism" }
```
