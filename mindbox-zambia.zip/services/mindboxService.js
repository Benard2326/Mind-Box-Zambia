function getResponse(message) {
  const msg = message.toLowerCase();

  if (msg.includes('tourism') || msg.includes('places to visit')) {
    return 'You can visit Victoria Falls, Lower Zambezi, or South Luangwa. Would you like directions or lodge options?';
  }

  if (msg.includes('loan') || msg.includes('bank')) {
    return 'Most Zambian banks like Zanaco and FNB offer mobile loans. Make sure you have your NRC and active mobile money. Want contact info?';
  }

  if (msg.includes('yango') || msg.includes('ride')) {
    return 'Yango rides in Lusaka cost around K30–K100 depending on the distance. Want help booking one?';
  }

  if (msg.includes('intercity') || msg.includes('bus')) {
    return 'Intercity buses like Power Tools and Mazhandu operate daily. Lusaka to Kitwe is about K250. Would you like booking contacts?';
  }

  return "I’m Mind Box Zambia – Ask me about tourism, banking, Yango or transport. I'm here to help!";
}

module.exports = { getResponse };